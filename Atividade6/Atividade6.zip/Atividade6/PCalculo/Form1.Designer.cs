﻿namespace PCalculo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDados = new System.Windows.Forms.Label();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.rbtnCasado = new System.Windows.Forms.RadioButton();
            this.lblDIRPF = new System.Windows.Forms.Label();
            this.lblDINSS = new System.Windows.Forms.Label();
            this.lblSalarioliquido = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblAliquotaIRFF = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.btnVerificaDesconto = new System.Windows.Forms.Button();
            this.nudNdFilho = new System.Windows.Forms.NumericUpDown();
            this.gBoxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.lblBumeriodeFilho = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNomeFuncionrio = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.pnl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNdFilho)).BeginInit();
            this.gBoxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(19, 176);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 43;
            this.lblDados.Text = "lblDados";
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(313, 265);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRPF.TabIndex = 42;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(313, 219);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 41;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(99, 355);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiq.TabIndex = 40;
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Location = new System.Drawing.Point(99, 308);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.Size = new System.Drawing.Size(100, 20);
            this.txtSalFam.TabIndex = 39;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(98, 265);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAliqIRPF.TabIndex = 38;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(98, 219);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliqINSS.TabIndex = 37;
            // 
            // pnl1
            // 
            this.pnl1.Controls.Add(this.rbtnCasado);
            this.pnl1.Location = new System.Drawing.Point(588, 162);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(200, 100);
            this.pnl1.TabIndex = 36;
            // 
            // rbtnCasado
            // 
            this.rbtnCasado.AutoSize = true;
            this.rbtnCasado.Location = new System.Drawing.Point(31, 22);
            this.rbtnCasado.Name = "rbtnCasado";
            this.rbtnCasado.Size = new System.Drawing.Size(61, 17);
            this.rbtnCasado.TabIndex = 2;
            this.rbtnCasado.TabStop = true;
            this.rbtnCasado.Text = "Casado";
            this.rbtnCasado.UseVisualStyleBackColor = true;
            // 
            // lblDIRPF
            // 
            this.lblDIRPF.AutoSize = true;
            this.lblDIRPF.Location = new System.Drawing.Point(227, 268);
            this.lblDIRPF.Name = "lblDIRPF";
            this.lblDIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDIRPF.TabIndex = 35;
            this.lblDIRPF.Text = "Desconto IRPF";
            // 
            // lblDINSS
            // 
            this.lblDINSS.AutoSize = true;
            this.lblDINSS.Location = new System.Drawing.Point(226, 222);
            this.lblDINSS.Name = "lblDINSS";
            this.lblDINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDINSS.TabIndex = 34;
            this.lblDINSS.Text = "Desconto INSS";
            // 
            // lblSalarioliquido
            // 
            this.lblSalarioliquido.AutoSize = true;
            this.lblSalarioliquido.Location = new System.Drawing.Point(19, 358);
            this.lblSalarioliquido.Name = "lblSalarioliquido";
            this.lblSalarioliquido.Size = new System.Drawing.Size(72, 13);
            this.lblSalarioliquido.TabIndex = 33;
            this.lblSalarioliquido.Text = "Salario liquido";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(19, 311);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalarioFamilia.TabIndex = 32;
            this.lblSalarioFamilia.Text = "Salário Familia";
            // 
            // lblAliquotaIRFF
            // 
            this.lblAliquotaIRFF.AutoSize = true;
            this.lblAliquotaIRFF.Location = new System.Drawing.Point(19, 268);
            this.lblAliquotaIRFF.Name = "lblAliquotaIRFF";
            this.lblAliquotaIRFF.Size = new System.Drawing.Size(72, 13);
            this.lblAliquotaIRFF.TabIndex = 31;
            this.lblAliquotaIRFF.Text = "Aliquota IRPF";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(19, 222);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAliquotaINSS.TabIndex = 30;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // btnVerificaDesconto
            // 
            this.btnVerificaDesconto.Location = new System.Drawing.Point(107, 134);
            this.btnVerificaDesconto.Name = "btnVerificaDesconto";
            this.btnVerificaDesconto.Size = new System.Drawing.Size(128, 23);
            this.btnVerificaDesconto.TabIndex = 29;
            this.btnVerificaDesconto.Text = "Verifica Desconto";
            this.btnVerificaDesconto.UseVisualStyleBackColor = true;
            this.btnVerificaDesconto.Click += new System.EventHandler(this.btnVerificaDesconto_Click);
            // 
            // nudNdFilho
            // 
            this.nudNdFilho.Location = new System.Drawing.Point(107, 92);
            this.nudNdFilho.Name = "nudNdFilho";
            this.nudNdFilho.Size = new System.Drawing.Size(120, 20);
            this.nudNdFilho.TabIndex = 28;
            // 
            // gBoxSexo
            // 
            this.gBoxSexo.Controls.Add(this.rbtnMasculino);
            this.gBoxSexo.Controls.Add(this.rbtnFeminino);
            this.gBoxSexo.Location = new System.Drawing.Point(588, 12);
            this.gBoxSexo.Name = "gBoxSexo";
            this.gBoxSexo.Size = new System.Drawing.Size(200, 100);
            this.gBoxSexo.TabIndex = 27;
            this.gBoxSexo.TabStop = false;
            this.gBoxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(45, 49);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(34, 17);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "M";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(45, 26);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(31, 17);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "F";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // lblBumeriodeFilho
            // 
            this.lblBumeriodeFilho.AutoSize = true;
            this.lblBumeriodeFilho.Location = new System.Drawing.Point(17, 94);
            this.lblBumeriodeFilho.Name = "lblBumeriodeFilho";
            this.lblBumeriodeFilho.Size = new System.Drawing.Size(84, 13);
            this.lblBumeriodeFilho.TabIndex = 24;
            this.lblBumeriodeFilho.Text = "Numero de Filho";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(17, 61);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalarioBruto.TabIndex = 23;
            this.lblSalarioBruto.Text = "Salario Bruto";
            // 
            // lblNomeFuncionrio
            // 
            this.lblNomeFuncionrio.AutoSize = true;
            this.lblNomeFuncionrio.Location = new System.Drawing.Point(17, 27);
            this.lblNomeFuncionrio.Name = "lblNomeFuncionrio";
            this.lblNomeFuncionrio.Size = new System.Drawing.Size(93, 13);
            this.lblNomeFuncionrio.TabIndex = 22;
            this.lblNomeFuncionrio.Text = "Nome Funcionário";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(273, 134);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 45;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(385, 134);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 46;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(116, 58);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(151, 20);
            this.txtSalarioBruto.TabIndex = 47;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(116, 24);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(209, 20);
            this.txtNomeFunc.TabIndex = 48;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 385);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.lblDIRPF);
            this.Controls.Add(this.lblDINSS);
            this.Controls.Add(this.lblSalarioliquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIRFF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.btnVerificaDesconto);
            this.Controls.Add(this.nudNdFilho);
            this.Controls.Add(this.gBoxSexo);
            this.Controls.Add(this.lblBumeriodeFilho);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFuncionrio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNdFilho)).EndInit();
            this.gBoxSexo.ResumeLayout(false);
            this.gBoxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.RadioButton rbtnCasado;
        private System.Windows.Forms.Label lblDIRPF;
        private System.Windows.Forms.Label lblDINSS;
        private System.Windows.Forms.Label lblSalarioliquido;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblAliquotaIRFF;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Button btnVerificaDesconto;
        private System.Windows.Forms.NumericUpDown nudNdFilho;
        private System.Windows.Forms.GroupBox gBoxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Label lblBumeriodeFilho;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNomeFuncionrio;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.TextBox txtNomeFunc;
    }
}

