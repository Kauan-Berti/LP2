﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            //Limpar dados 
            MskbxLadoA.Clear();
            MskbxLadoB.Clear();
            MskbxLadoC.Clear();

            MskbxLadoA.Focus();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            Double A, B, C;
            if (Double.TryParse(MskbxLadoA.Text, out A) &&
               (Double.TryParse(MskbxLadoB.Text, out B) &&
               (Double.TryParse(MskbxLadoC.Text, out C))))
            {
                if (A == B && B == C)
                {
                    MessageBox.Show(" Os 3 Valores formam um Triangulo Equilátero ");
                }
                else if (A == B || B == C || C == A)
                {
                    MessageBox.Show(" Os 3 Valores formam um Triangulo Isósceles ");
                }
                else if (A != B && B != C && A != C)
                {
                    MessageBox.Show(" Os 3 Valores Formam um Triangulo Escaleno ");
                }
            }
        }
    }
}
