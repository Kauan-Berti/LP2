﻿namespace Atividade4
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblLadoA = new System.Windows.Forms.Label();
            this.LblLadoB = new System.Windows.Forms.Label();
            this.LblLAdoC = new System.Windows.Forms.Label();
            this.MskbxLadoA = new System.Windows.Forms.MaskedTextBox();
            this.MskbxLadoB = new System.Windows.Forms.MaskedTextBox();
            this.MskbxLadoC = new System.Windows.Forms.MaskedTextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblLadoA
            // 
            this.LblLadoA.AutoSize = true;
            this.LblLadoA.Location = new System.Drawing.Point(27, 29);
            this.LblLadoA.Name = "LblLadoA";
            this.LblLadoA.Size = new System.Drawing.Size(41, 13);
            this.LblLadoA.TabIndex = 0;
            this.LblLadoA.Text = "Lado A";
            // 
            // LblLadoB
            // 
            this.LblLadoB.AutoSize = true;
            this.LblLadoB.Location = new System.Drawing.Point(27, 59);
            this.LblLadoB.Name = "LblLadoB";
            this.LblLadoB.Size = new System.Drawing.Size(41, 13);
            this.LblLadoB.TabIndex = 1;
            this.LblLadoB.Text = "Lado B";
            // 
            // LblLAdoC
            // 
            this.LblLAdoC.AutoSize = true;
            this.LblLAdoC.Location = new System.Drawing.Point(27, 91);
            this.LblLAdoC.Name = "LblLAdoC";
            this.LblLAdoC.Size = new System.Drawing.Size(41, 13);
            this.LblLAdoC.TabIndex = 2;
            this.LblLAdoC.Text = "Lado C";
            // 
            // MskbxLadoA
            // 
            this.MskbxLadoA.Location = new System.Drawing.Point(99, 26);
            this.MskbxLadoA.Mask = "00.0";
            this.MskbxLadoA.Name = "MskbxLadoA";
            this.MskbxLadoA.Size = new System.Drawing.Size(100, 20);
            this.MskbxLadoA.TabIndex = 3;
            // 
            // MskbxLadoB
            // 
            this.MskbxLadoB.Location = new System.Drawing.Point(99, 56);
            this.MskbxLadoB.Mask = "00.0";
            this.MskbxLadoB.Name = "MskbxLadoB";
            this.MskbxLadoB.Size = new System.Drawing.Size(100, 20);
            this.MskbxLadoB.TabIndex = 4;
            // 
            // MskbxLadoC
            // 
            this.MskbxLadoC.Location = new System.Drawing.Point(99, 88);
            this.MskbxLadoC.Mask = "00.0";
            this.MskbxLadoC.Name = "MskbxLadoC";
            this.MskbxLadoC.Size = new System.Drawing.Size(100, 20);
            this.MskbxLadoC.TabIndex = 5;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(30, 136);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(75, 23);
            this.BtnCalcular.TabIndex = 6;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(124, 136);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(75, 23);
            this.BtnLimpar.TabIndex = 7;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(218, 136);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 174);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.MskbxLadoC);
            this.Controls.Add(this.MskbxLadoB);
            this.Controls.Add(this.MskbxLadoA);
            this.Controls.Add(this.LblLAdoC);
            this.Controls.Add(this.LblLadoB);
            this.Controls.Add(this.LblLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblLadoA;
        private System.Windows.Forms.Label LblLadoB;
        private System.Windows.Forms.Label LblLAdoC;
        private System.Windows.Forms.MaskedTextBox MskbxLadoA;
        private System.Windows.Forms.MaskedTextBox MskbxLadoB;
        private System.Windows.Forms.MaskedTextBox MskbxLadoC;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
    }
}

