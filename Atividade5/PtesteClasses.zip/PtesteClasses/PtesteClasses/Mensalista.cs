﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteClasses
{

        class Mensalista : Empregado // especialização -> heranca
        {
            public Double SalarioMensal { get; set; }

            //sobreescrevendo o método
            public override double SalarioBruto()
            {
                return SalarioMensal;
            }

            // contrutor -->

            public Mensalista()
            {
                  MessageBox.Show("passei por aqui");
            }
            
            public Mensalista(double )
            { 

            }
            public Mensalista(int matx, string nomex, DateTime datax, double salariox)
            {
                Matricula = matx;
                NomeEmpregado = nomex;
                DataEntradaEmpresa = datax;
                SalarioMensal = salariox;
            }
    }
}
