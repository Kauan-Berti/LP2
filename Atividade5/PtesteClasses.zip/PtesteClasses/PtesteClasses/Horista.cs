﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PtesteClasses
{
    internal class Horista : Empregado
     //não posso herdar mais de uma clase. Não existe herança multipla
    {
        // prop e 2  tab cria a estrutura da propiedade
        public double SalarioHora { get; set; } 
        
        public double NumeroHora { get; set; }  

        public int DiasFalta { get; set; }

        public override Double SalarioBruto()
        {
            return (SalarioBruto * NumeroHora);
        }
        // override indica sobreescreve 

        public override int TempoTrabalhado()
        {
            // o metodo retorna um tipo span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days - DiasFalta);
        }
    }
}
