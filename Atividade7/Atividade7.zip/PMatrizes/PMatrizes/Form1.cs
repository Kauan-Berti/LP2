﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; // Project > Add References > Visual Basic    |  dps adiciona essa linha de codigo
using System.Collections;


namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverteVetor_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número: ", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int result in vetor)
            {
                auxiliar += result + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            string lista = "";
            ArrayList nomes = new ArrayList();

            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fatima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");
            nomes.Remove("Otávio");

            foreach (var item in nomes)
            {
                lista += item + "\n";
            }
            MessageBox.Show(lista);
        }

        private void btnMercadoria_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            double faturamento = 0;
            string auxiliar;

            for (var i = 0; i < quantidade.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da marcadoria " + (i + 1),
                    "Entrada de Dados");
                if (!double.TryParse(auxiliar, out quantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
                }
                else
                {

                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço da mercadoria " + (i + 1),
                            "Entrada dos Preços");
                        if (!double.TryParse(auxiliar, out preco[i]))
                        {
                            MessageBox.Show("Preço inválido!");
                        }
                        else
                        {
                            if (preco[i] <= 0)
                            {
                                MessageBox.Show("O preço deve ser maior que zero!");
                            }
                        }
                    }

                    faturamento += quantidade[i] * preco[i];

                }
            }

            MessageBox.Show("Faturamento: " + faturamento.ToString("N2"));
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            string auxiliar = "";
            string mensagem = "";
            int i = 0, j = 0;

            for (i = 0; i < 20; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota: " + (j + 1) + " do aluno: " + (i + 1) + ";");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                        media = media + notas[i, j];
                }

                media = media / 3;
                mensagem += "Aluno: " + (i + 1) + " - media: " + media.ToString() + "\n";
                media = 0;
            }
            MessageBox.Show(mensagem);
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            string[] alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo",
                               "Jose", "Nelma", "Tobby"};
            Int32 i, total = 0;
            Int32 n = alunos.Length;

            for (i = 0; i < n - 1; i++)
            {
                total += alunos[i].Length;
            }

            MessageBox.Show(total.ToString());
        }

        private void btnNomesPessoas_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["NomesPessoas"];
            if (fc != null)
                fc.Close();

            NomesPessoas frm = new NomesPessoas();
            frm.Show();
        }
    }
}
