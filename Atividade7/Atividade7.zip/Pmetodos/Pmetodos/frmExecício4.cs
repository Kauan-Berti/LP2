﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExecício4 : Form
    {
        public frmExecício4()
        {
            InitializeComponent();
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            int numericos = 0;
            string letra;
            letra = rctbxTexto.Text;

            for (int i = 0; i < rctbxTexto.Text.Length; i++)
            {
                if (Char.IsNumber(letra, i))
                    numericos++;
            }

            MessageBox.Show("Há " + numericos + " caracteres numericos no campo de texto");
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int posicao = -1, i = 0;
            string texto;
            texto = rctbxTexto.Text;

            while (posicao < 0)
            {
                if (Char.IsWhiteSpace(texto, i))
                {
                    posicao = i;
                    MessageBox.Show("Espaço em branco na posição: " + posicao);
                }
                if (i == texto.Length)
                {
                    MessageBox.Show("Não há espaço em branco");
                    break;
                }
                i++;

            }
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            int qtdAlfabeto = 0;

            char[] arr = rctbxTexto.Text.ToCharArray();

            foreach (var letra in arr)
            {
                if (Char.IsLetter(letra))
                    qtdAlfabeto++;
            }

            MessageBox.Show("Existem " + qtdAlfabeto + " carateres alfabeticos no campo de texto");
        }
    }
}
