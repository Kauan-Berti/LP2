﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExecício2 : Form
    {
        public frmExecício2()
        {
            InitializeComponent();
        }

        private void btnTestarIgual_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtpalavra1.Text, 
                txtpalavra2.Text, true) == 0) // ignorecase=true
                MessageBox.Show("Saão Iguais");
            else
                MessageBox.Show("Saão Diferentes");
        }

        private void btnInTx1_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra2.Text.Length / 2;
            /*       a     a      x
             *     casa fatec assesoria
             *meio   2    2      5
            */

            txtpalavra2.Text = txtpalavra2.Text.Substring(0, meio) +
                txtpalavra1.Text + txtpalavra2.Text.Substring(meio,
                txtpalavra2.Text.Length - meio);

        }

        private void btnInsAsteriscos_Click(object sender, EventArgs e)
        {
            int meio = txtpalavra1.Text.Length / 2;
            txtpalavra2.Text = txtpalavra1.Text.Insert(meio, "**");

            //casa --> ca**sa
            //fatec --> fa**tec
            // sorocaba --> soro**caba
        }
    }
}
