﻿namespace Pmetodos
{
    partial class frmExecício3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverte = new System.Windows.Forms.Button();
            this.btnROReplace = new System.Windows.Forms.Button();
            this.btnRemoveOcorre = new System.Windows.Forms.Button();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInverte
            // 
            this.btnInverte.Location = new System.Drawing.Point(332, 95);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(133, 49);
            this.btnInverte.TabIndex = 13;
            this.btnInverte.Text = "Invete (Reverse)";
            this.btnInverte.UseVisualStyleBackColor = true;
            this.btnInverte.Click += new System.EventHandler(this.btnInverte_Click);
            // 
            // btnROReplace
            // 
            this.btnROReplace.Location = new System.Drawing.Point(177, 95);
            this.btnROReplace.Name = "btnROReplace";
            this.btnROReplace.Size = new System.Drawing.Size(133, 49);
            this.btnROReplace.TabIndex = 12;
            this.btnROReplace.Text = "Remove Ocorrências (replace)";
            this.btnROReplace.UseVisualStyleBackColor = true;
            this.btnROReplace.Click += new System.EventHandler(this.btnROReplace_Click);
            // 
            // btnRemoveOcorre
            // 
            this.btnRemoveOcorre.Location = new System.Drawing.Point(16, 95);
            this.btnRemoveOcorre.Name = "btnRemoveOcorre";
            this.btnRemoveOcorre.Size = new System.Drawing.Size(133, 49);
            this.btnRemoveOcorre.TabIndex = 11;
            this.btnRemoveOcorre.Text = "Remove Ocorrências";
            this.btnRemoveOcorre.UseVisualStyleBackColor = true;
            this.btnRemoveOcorre.Click += new System.EventHandler(this.btnRemoveOcorre_Click);
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(80, 49);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(206, 20);
            this.txtpalavra2.TabIndex = 10;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(80, 19);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(206, 20);
            this.txtpalavra1.TabIndex = 9;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(22, 52);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 8;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(22, 22);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 7;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // frmExecício3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 171);
            this.Controls.Add(this.btnInverte);
            this.Controls.Add(this.btnROReplace);
            this.Controls.Add(this.btnRemoveOcorre);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExecício3";
            this.Text = "frmExecício3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInverte;
        private System.Windows.Forms.Button btnROReplace;
        private System.Windows.Forms.Button btnRemoveOcorre;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
    }
}