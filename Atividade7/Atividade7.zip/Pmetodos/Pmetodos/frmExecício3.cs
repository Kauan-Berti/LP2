﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExecício3 : Form
    {
        public frmExecício3()
        {
            InitializeComponent();
        }

        private void btnRemoveOcorre_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            txtpalavra1.Text = txtpalavra1.Text.ToUpper();
            txtpalavra2.Text = txtpalavra2.Text.ToUpper();

            posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);

            while (posicao >= 0) // a busca do indexof inicia em zero
            {
                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) +
                txtpalavra2.Text.Substring(posicao + txtpalavra1.Text.Length,
                txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);

                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);

            }



        }

        private void btnROReplace_Click(object sender, EventArgs e)
        {
            txtpalavra1.Text = txtpalavra1.Text.ToUpper();
            txtpalavra2.Text = txtpalavra2.Text.ToUpper();

            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void btnInverte_Click(object sender, EventArgs e)
        {
            string auxiliar = txtpalavra1.Text;
            char[] arr = auxiliar.ToCharArray(); //joga o conteudo da string para um array de char
            Array.Reverse(arr); // inverte o array

            auxiliar = "";
            foreach (char letra in arr)
            {
                auxiliar += letra.ToString();
            }

            // MessageBox.Show(auxiliar);
            txtpalavra2.Text = auxiliar;
        }
    }
}
