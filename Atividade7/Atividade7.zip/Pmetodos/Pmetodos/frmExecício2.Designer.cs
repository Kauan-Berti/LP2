﻿namespace Pmetodos
{
    partial class frmExecício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btnTestarIgual = new System.Windows.Forms.Button();
            this.btnInTx1 = new System.Windows.Forms.Button();
            this.btnInsAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(18, 17);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(18, 47);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(76, 14);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(206, 20);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(76, 44);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(206, 20);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btnTestarIgual
            // 
            this.btnTestarIgual.Location = new System.Drawing.Point(12, 90);
            this.btnTestarIgual.Name = "btnTestarIgual";
            this.btnTestarIgual.Size = new System.Drawing.Size(133, 49);
            this.btnTestarIgual.TabIndex = 4;
            this.btnTestarIgual.Text = "Testar Iguais";
            this.btnTestarIgual.UseVisualStyleBackColor = true;
            this.btnTestarIgual.Click += new System.EventHandler(this.btnTestarIgual_Click);
            // 
            // btnInTx1
            // 
            this.btnInTx1.Location = new System.Drawing.Point(173, 90);
            this.btnInTx1.Name = "btnInTx1";
            this.btnInTx1.Size = new System.Drawing.Size(133, 49);
            this.btnInTx1.TabIndex = 5;
            this.btnInTx1.Text = "Inserir Texto 1 no Texto 2 ";
            this.btnInTx1.UseVisualStyleBackColor = true;
            this.btnInTx1.Click += new System.EventHandler(this.btnInTx1_Click);
            // 
            // btnInsAsteriscos
            // 
            this.btnInsAsteriscos.Location = new System.Drawing.Point(329, 90);
            this.btnInsAsteriscos.Name = "btnInsAsteriscos";
            this.btnInsAsteriscos.Size = new System.Drawing.Size(133, 49);
            this.btnInsAsteriscos.TabIndex = 6;
            this.btnInsAsteriscos.Text = "Inserir Asteriscos no Texto 1";
            this.btnInsAsteriscos.UseVisualStyleBackColor = true;
            this.btnInsAsteriscos.Click += new System.EventHandler(this.btnInsAsteriscos_Click);
            // 
            // frmExecício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 155);
            this.Controls.Add(this.btnInsAsteriscos);
            this.Controls.Add(this.btnInTx1);
            this.Controls.Add(this.btnTestarIgual);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExecício2";
            this.Text = "frmExecício2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btnTestarIgual;
        private System.Windows.Forms.Button btnInTx1;
        private System.Windows.Forms.Button btnInsAsteriscos;
    }
}