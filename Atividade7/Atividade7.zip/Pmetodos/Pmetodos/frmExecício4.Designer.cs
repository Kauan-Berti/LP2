﻿namespace Pmetodos
{
    partial class frmExecício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAlfabetico = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnNumerico = new System.Windows.Forms.Button();
            this.rctbxTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnAlfabetico
            // 
            this.btnAlfabetico.Location = new System.Drawing.Point(404, 191);
            this.btnAlfabetico.Name = "btnAlfabetico";
            this.btnAlfabetico.Size = new System.Drawing.Size(127, 65);
            this.btnAlfabetico.TabIndex = 7;
            this.btnAlfabetico.Text = "Alfabético";
            this.btnAlfabetico.UseVisualStyleBackColor = true;
            this.btnAlfabetico.Click += new System.EventHandler(this.btnAlfabetico_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(218, 191);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(127, 65);
            this.btnEspaco.TabIndex = 6;
            this.btnEspaco.Text = "Primeiro Espaço em Branco";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnNumerico
            // 
            this.btnNumerico.Location = new System.Drawing.Point(23, 191);
            this.btnNumerico.Name = "btnNumerico";
            this.btnNumerico.Size = new System.Drawing.Size(127, 65);
            this.btnNumerico.TabIndex = 5;
            this.btnNumerico.Text = "Numérico";
            this.btnNumerico.UseVisualStyleBackColor = true;
            this.btnNumerico.Click += new System.EventHandler(this.btnNumerico_Click);
            // 
            // rctbxTexto
            // 
            this.rctbxTexto.Location = new System.Drawing.Point(23, 26);
            this.rctbxTexto.Name = "rctbxTexto";
            this.rctbxTexto.Size = new System.Drawing.Size(508, 131);
            this.rctbxTexto.TabIndex = 4;
            this.rctbxTexto.Text = "";
            // 
            // frmExecício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 288);
            this.Controls.Add(this.btnAlfabetico);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnNumerico);
            this.Controls.Add(this.rctbxTexto);
            this.Name = "frmExecício4";
            this.Text = "frmExecício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAlfabetico;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnNumerico;
        private System.Windows.Forms.RichTextBox rctbxTexto;
    }
}