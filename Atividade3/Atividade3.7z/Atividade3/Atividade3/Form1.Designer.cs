﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.LblPeso = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblIMC = new System.Windows.Forms.Label();
            this.MskbxPeso = new System.Windows.Forms.MaskedTextBox();
            this.MskbxAltura = new System.Windows.Forms.MaskedTextBox();
            this.TxtIMC = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(12, 178);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(75, 23);
            this.BtnCalcular.TabIndex = 0;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Location = new System.Drawing.Point(142, 178);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(75, 23);
            this.BtnLimpar.TabIndex = 1;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(267, 178);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 2;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // LblPeso
            // 
            this.LblPeso.AutoSize = true;
            this.LblPeso.Location = new System.Drawing.Point(33, 58);
            this.LblPeso.Name = "LblPeso";
            this.LblPeso.Size = new System.Drawing.Size(31, 13);
            this.LblPeso.TabIndex = 3;
            this.LblPeso.Text = "Peso";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(33, 100);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(34, 13);
            this.LblAltura.TabIndex = 4;
            this.LblAltura.Text = "Altura";
            // 
            // LblIMC
            // 
            this.LblIMC.AutoSize = true;
            this.LblIMC.Location = new System.Drawing.Point(33, 140);
            this.LblIMC.Name = "LblIMC";
            this.LblIMC.Size = new System.Drawing.Size(26, 13);
            this.LblIMC.TabIndex = 5;
            this.LblIMC.Text = "IMC";
            // 
            // MskbxPeso
            // 
            this.MskbxPeso.Location = new System.Drawing.Point(130, 55);
            this.MskbxPeso.Mask = "00.00";
            this.MskbxPeso.Name = "MskbxPeso";
            this.MskbxPeso.Size = new System.Drawing.Size(100, 20);
            this.MskbxPeso.TabIndex = 6;
            // 
            // MskbxAltura
            // 
            this.MskbxAltura.Location = new System.Drawing.Point(130, 97);
            this.MskbxAltura.Mask = "0.00";
            this.MskbxAltura.Name = "MskbxAltura";
            this.MskbxAltura.Size = new System.Drawing.Size(100, 20);
            this.MskbxAltura.TabIndex = 7;
            // 
            // TxtIMC
            // 
            this.TxtIMC.Enabled = false;
            this.TxtIMC.Location = new System.Drawing.Point(130, 137);
            this.TxtIMC.Name = "TxtIMC";
            this.TxtIMC.ReadOnly = true;
            this.TxtIMC.Size = new System.Drawing.Size(100, 20);
            this.TxtIMC.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(330, 20);
            this.textBox1.TabIndex = 9;
            this.textBox1.Text = "Calcule seu IMC";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 208);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.TxtIMC);
            this.Controls.Add(this.MskbxAltura);
            this.Controls.Add(this.MskbxPeso);
            this.Controls.Add(this.LblIMC);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblPeso);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.BtnCalcular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.Label LblPeso;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblIMC;
        private System.Windows.Forms.MaskedTextBox MskbxPeso;
        private System.Windows.Forms.MaskedTextBox MskbxAltura;
        private System.Windows.Forms.TextBox TxtIMC;
        private System.Windows.Forms.TextBox textBox1;
    }
}

