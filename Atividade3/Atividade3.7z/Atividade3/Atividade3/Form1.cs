﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {

            Double IMC, Peso, Altura;

            if (Double.TryParse(MskbxPeso.Text, out Peso) &&
                Double.TryParse(MskbxAltura.Text, out Altura))
            {
                IMC = Peso / Math.Pow(Altura, 2);
                TxtIMC.Text = IMC.ToString();

                if (IMC <= 18.5)
                {
                    MessageBox.Show("Classificação: Magreza; Obesidade Grau: 0 ");
                }
                else if (IMC <= 24.9)
                {
                    MessageBox.Show("Classificação: Normal; Obesidade Grau: 0 ");
                }
                else if (IMC <= 29.9)
                {
                    MessageBox.Show("Classificação: Sobrepeso; Obesidade Grau: I ");
                }
                else if (IMC <= 39.9)
                {
                    MessageBox.Show("Classificação: Obesidade; Obesidade Grau: II ");
                }
                else if (IMC > 40)
                {
                    MessageBox.Show("Classificação: Obesidade Grave; Obesidade Grau: III ");
                }
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            //limpar o dado 
            MskbxPeso.Clear();
            MskbxAltura.Clear();
            TxtIMC.Clear();

            MskbxPeso.Focus();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
